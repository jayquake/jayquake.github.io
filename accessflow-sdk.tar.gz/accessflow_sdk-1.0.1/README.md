# AccessFlow SDK for Python

Professional accessibility testing for Python applications using Playwright. Automatically detect WCAG 2.1 accessibility issues in your tests.

## Installation

### From PyPI (Production)

```bash
pip install accessflow-sdk
```

### From Local Package File

If you've received a package file directly (without access to PyPI):

```bash
# Install from wheel file (recommended)
pip install /path/to/accessflow_sdk-1.0.1-py3-none-any.whl

# Or from tar.gz source distribution
pip install /path/to/accessflow-sdk.tar.gz
```

## Quick Start

### 1. Configure API Key

**Option 1: Environment Variable (Recommended)**

Set `ACCESSFLOW_SDK_API_KEY` in your environment - the SDK will automatically use it:

```bash
# .env file or shell
export ACCESSFLOW_SDK_API_KEY=your-api-key-here
```

```python
from accessflow_sdk import AccessFlowSDK

# No api_key parameter needed - reads from environment automatically
sdk = AccessFlowSDK(page)
```

**For CI/CD pipelines**, set as a **secret environment variable** in your CI platform:

```yaml
# GitHub Actions
env:
  ACCESSFLOW_SDK_API_KEY: ${{ secrets.ACCESSFLOW_SDK_API_KEY }}
```

```yaml
# CircleCI
environment:
  ACCESSFLOW_SDK_API_KEY: ${ACCESSFLOW_SDK_API_KEY}
```

```yaml
# GitLab CI
variables:
  ACCESSFLOW_SDK_API_KEY: $ACCESSFLOW_SDK_API_KEY
```

**Option 2: Pass to Constructor**

When you need to set the API key programmatically:

```python
sdk = AccessFlowSDK(page, api_key='your-api-key-here')
```

**Option 3: Use Configuration Dictionary**

For advanced configuration:

```python
sdk = AccessFlowSDK(page, config={
    'apiToken': 'your-api-key-here',
    'projectId': 'your-project-id',
    'includeNotices': True
})
```

### 2. Basic Usage

```python
from playwright.sync_api import sync_playwright
from accessflow_sdk import AccessFlowSDK

def test_homepage_accessibility():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()
        
        # Initialize SDK
        sdk = AccessFlowSDK(page)
        page.goto("https://example.com")
        
        # Run audit
        audits = sdk.audit()
        report = sdk.generate_report(audits)
        
        # Check results
        print(f"Issues found: {report['numberOfIssuesFound']}")
        assert report['numberOfIssuesFound'].get('extreme', 0) == 0
        
        browser.close()
```

### 3. Pytest Integration (Recommended)

Create `conftest.py`:

```python
import pytest
from accessflow_sdk import finalize_reports, record_audit

@pytest.fixture
def sdk(page):
    """Provides AccessFlow SDK with automatic recording"""
    from accessflow_sdk import AccessFlowSDK
    sdk_instance = AccessFlowSDK(page)
    
    # Wrap audit method to automatically record results
    original_audit = sdk_instance.audit
    
    def audit_with_recording():
        result = original_audit()
        record_audit(page.url, result)
        return result
    
    sdk_instance.audit = audit_with_recording
    return sdk_instance

@pytest.fixture(scope="session", autouse=True)
def finalize_accessibility_reports():
    """Automatically upload reports after all tests complete"""
    yield
    finalize_reports()
```

Then use in your tests:

```python
def test_homepage(page, sdk):
    page.goto("https://example.com")
    
    audits = sdk.audit()
    report = sdk.generate_report(audits)
    
    # Assert no critical issues
    assert report['numberOfIssuesFound'].get('extreme', 0) == 0
    assert report['numberOfIssuesFound'].get('high', 0) <= 5
```

## API Reference

### AccessFlowSDK

```python
class AccessFlowSDK(page, config=None)
```

**Parameters:**
- `page` (Page): Playwright Page object
- `config` (dict, optional): Configuration dictionary
  - `apiToken` (str): API key (defaults to `ACCESSFLOW_SDK_API_KEY` env var)
  - `projectId` (str): Project ID (optional)
  - `includeNotices` (bool): Include notices in reports (default: False)

#### Methods

##### `audit() -> dict`

Runs accessibility audit on the current page and returns raw audit data.

```python
audits = sdk.audit()
```

**Returns:** Dictionary containing raw audit results

##### `generate_report(audits, export_type='json') -> dict`

Generates a summary report from audit results.

```python
report = sdk.generate_report(audits)
```

**Parameters:**
- `audits` (dict): Raw audit data from `audit()`
- `export_type` (str): Report format (currently only 'json')

**Returns:**
```python
{
    'numberOfIssuesFound': {
        'extreme': 0,
        'high': 5,
        'medium': 8,
        'low': 12
    },
    'ruleViolations': {
        'colorContrast': {
            'name': 'Color Contrast',
            'severity': 'medium',
            'numberOfOccurrences': 3,
            'WCAGLevel': 'AA',
            'WCAGLink': 'https://www.w3.org/WAI/WCAG21/...',
            'description': 'Ensure sufficient color contrast...',
            'selectors': ['.header', '.footer']
        }
    }
}
```

### Teardown Functions

#### `record_audit(url: str, audits: dict)`

Records an audit for later aggregation (useful for parallel test execution).

```python
from accessflow_sdk import record_audit

record_audit(page.url, audits)
```

#### `finalize_reports(api_key: str = None, run_id: str = None, output_dir: str = './test-results')`

Finalizes and uploads all recorded audits. Call this once after all tests complete.

```python
from accessflow_sdk import finalize_reports

finalize_reports()
```

**Parameters:**
- `api_key` (str, optional): Override API key from environment
- `run_id` (str, optional): Custom run ID for reports
- `output_dir` (str): Directory for local JSON reports (default: './test-results')

## Configuration

Create `accessflow.config.json` in your project root:

```json
{
  "issuesFoundThreshold": {
    "extreme": 0,
    "high": 5,
    "medium": 10,
    "low": 20
  },
  "localCheck": false
}
```

**Options:**
- `issuesFoundThreshold`: Maximum allowed issues per severity level
- `localCheck`: Apply thresholds in local development (default: false, applies in CI only)

## How It Works

### Local Development
- ✅ Audits run on each page
- ✅ JSON reports saved to `./test-results` directory
- ❌ Reports NOT uploaded to dashboard (prevents accidental uploads)

### CI/CD Environment
- ✅ Audits run on each page
- ✅ Results aggregated from parallel test workers
- ✅ Automatically uploaded to AccessFlow dashboard
- ✅ Threshold checks applied (fail build if exceeded)

**Supported CI platforms:** CircleCI, GitHub Actions, GitLab CI, Jenkins, Azure Pipelines, Bitbucket Pipelines, Travis CI

## Advanced Usage

### Custom Configuration

```python
sdk = AccessFlowSDK(page, config={
    'apiToken': 'your-api-key',
    'projectId': 'your-project-id',
    'includeNotices': True
})
```

### Multiple Pages

```python
def test_multi_page(page, sdk):
    # Test homepage
    page.goto("https://example.com")
    home_audits = sdk.audit()
    
    # Test about page
    page.goto("https://example.com/about")
    about_audits = sdk.audit()
    
    # Generate reports
    home_report = sdk.generate_report(home_audits)
    about_report = sdk.generate_report(about_audits)
```

### Async Playwright

```python
import pytest
from playwright.async_api import async_playwright
from accessflow_sdk import AccessFlowSDK

@pytest.mark.asyncio
async def test_async_accessibility():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        
        sdk = AccessFlowSDK(page)
        await page.goto("https://example.com")
        
        audits = sdk.audit()  # Note: audit() is synchronous
        report = sdk.generate_report(audits)
        
        assert report['numberOfIssuesFound'].get('extreme', 0) == 0
        await browser.close()
```

## Requirements

- Python 3.7+
- Playwright for Python (`pip install playwright`)
- Playwright browsers installed (`playwright install`)

## Troubleshooting

### API Key Issues

```python
# Check if environment variable is set
import os
print(os.getenv('ACCESSFLOW_SDK_API_KEY'))

# Pass API key explicitly
sdk = AccessFlowSDK(page, api_key='your-api-key')

# Or use config dict
sdk = AccessFlowSDK(page, config={'apiToken': 'your-api-key'})
```

**Never hardcode API keys in your source code!** Use:
- Constructor parameters for local development
- Environment variables for CI/CD (stored as secrets)
- Configuration files excluded from version control

### Reports Not Uploading

- Ensure `CI=true` is set in your CI environment
- Check `finalize_reports()` is called after all tests
- Verify API key has upload permissions

### Playwright Browser Not Found

```bash
# Install Playwright browsers
playwright install chromium
```

## Examples

See the [`examples/python`](../examples/python) directory for complete working examples.

## License

ISC

## Support

- **Documentation:** https://docs.accessflow.com
- **Dashboard:** https://dashboard.accessflow.com
- **Issues:** https://github.com/acsbe/accessFlow/issues
