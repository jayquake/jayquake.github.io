"""
Global teardown functionality for pytest integration
"""
import subprocess
import tempfile
import json
import os
from typing import Dict, Any, Optional, List
from pathlib import Path
import platform


# Global state for collecting audits across tests
_audit_records: List[Dict[str, Any]] = []


def record_audit(url: str, audits: Dict[str, Any]) -> None:
    """
    Record an audit result for later aggregation
    
    Args:
        url: URL that was audited
        audits: Raw audit results from sdk.audit()
    """
    global _audit_records
    _audit_records.append({'url': url, 'audits': audits})


def finalize_reports(
    api_key: Optional[str] = None,
    run_id: Optional[str] = None,
    output_dir: str = './test-results'
) -> None:
    """
    Finalize and upload all recorded audits (call in pytest teardown)
    
    This should be called once after all tests complete, typically in a
    session-scoped pytest fixture with autouse=True.
    
    Args:
        api_key: AccessFlow API key (defaults to ACCESSFLOW_SDK_API_KEY env var)
        run_id: Unique run identifier (auto-detected from CI environment)
        output_dir: Directory to store state files
    """
    global _audit_records
    
    if not _audit_records:
        return
    
    # Detect CI environment
    is_ci = any(key in os.environ for key in [
        'CI', 'JENKINS_URL', 'GITHUB_ACTIONS', 'GITLAB_CI',
        'CIRCLECI', 'TRAVIS', 'BITBUCKET_BUILD_NUMBER'
    ])
    
    if not is_ci:
        print("Not in CI environment - skipping upload")
        return
    
    # Get run ID from CI environment
    if not run_id:
        run_id = (
            os.environ.get('GITHUB_RUN_ID') or
            os.environ.get('CI_PIPELINE_ID') or
            os.environ.get('CIRCLE_BUILD_NUM') or
            'local'
        )
    
    # Get API key
    key = api_key or os.environ.get('ACCESSFLOW_SDK_API_KEY')
    if not key:
        print("Warning: No API key provided - cannot upload reports")
        return
    
    # Get CLI path
    cli_path = _get_cli_path()
    
    # Record all audits
    print(f"Recording {len(_audit_records)} audit(s)...")
    for record in _audit_records:
        with tempfile.NamedTemporaryFile(mode='w', suffix='.json', delete=False) as f:
            json.dump(record['audits'], f)
            temp_file = f.name
        
        try:
            subprocess.run([
                cli_path,
                'record',
                '--id', run_id,
                '--file', temp_file,
                '--url', record['url'],
                '--output', output_dir
            ], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Failed to record audit: {e}")
        finally:
            os.unlink(temp_file)
    
    # Finalize and upload
    print("Finalizing and uploading report...")
    try:
        result = subprocess.run([
            cli_path,
            'finalize',
            '--id', run_id,
            '--api-key', key,
            '--output', output_dir
        ], check=True, capture_output=True, text=True)
        print("✓ Report uploaded successfully")
        if result.stdout:
            print(f"CLI output: {result.stdout}")
        if result.stderr:
            print(f"CLI errors: {result.stderr}")
    except subprocess.CalledProcessError as e:
        print(f"✗ Failed to upload report: {e}")
        if e.stdout:
            print(f"CLI output: {e.stdout}")
        if e.stderr:
            print(f"CLI errors: {e.stderr}")


def _get_cli_path() -> str:
    """Get the CLI binary path for the current platform"""
    system = platform.system().lower()
    machine = platform.machine().lower()
    
    # Get package directory
    package_dir = Path(__file__).parent
    bin_dir = package_dir / "bin"
    
    if system == 'darwin':
        arch = 'arm64' if 'arm' in machine or 'aarch64' in machine else 'x64'
        binary = f"aflow-core-macos-{arch}"
    elif system == 'linux':
        binary = "aflow-core-linux-x64"
    elif system == 'windows':
        binary = "aflow-core-win-x64.exe"
    else:
        raise RuntimeError(f"Unsupported platform: {system}")
    
    path = bin_dir / binary
    
    if not path.exists():
        raise FileNotFoundError(f"CLI binary not found at {path}")
    
    # Make executable on Unix systems
    if system != 'windows':
        os.chmod(path, 0o755)
    
    return str(path)
