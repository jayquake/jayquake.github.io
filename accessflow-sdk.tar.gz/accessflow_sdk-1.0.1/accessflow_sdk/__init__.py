"""
AccessFlow SDK for Python

Professional accessibility testing for web applications.
Integrates with Playwright to automatically detect accessibility issues.
"""

from .sdk import AccessFlowSDK
from .teardown import record_audit, finalize_reports

__version__ = "1.0.1"
__all__ = ["AccessFlowSDK", "record_audit", "finalize_reports"]
