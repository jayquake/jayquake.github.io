# AccessFlow SDK

Professional accessibility testing SDK for web applications. Automatically detect WCAG 2.1 accessibility issues in your tests.

[![License: ISC](https://img.shields.io/badge/License-ISC-blue.svg)](https://opensource.org/licenses/ISC)

## Supported Languages

| Language                  | Package                  |
| ------------------------- | ------------------------ |
| **JavaScript/TypeScript** | @acsbe/accessflow-sdk    |
| **Python**                | accessflow-sdk           |
| **Java**                  | com.acsbe:accessflow-sdk |

## Features

- **Multi-language support** - JavaScript, Python, and Java
- **WCAG 2.1 compliance** checking (A, AA, AAA)
- **Playwright integration** - Works seamlessly with Playwright tests
- **Detailed reports** - Issue descriptions, severity levels, and selectors
- **CI/CD ready** - Automatic report uploads to AccessFlow Dashboard
- **Configurable thresholds** - Fail builds on accessibility violations
- **Parallel execution** - Supports parallel test runners
- **Cross-platform** - Windows, macOS, Linux

## Prerequisites

You will receive the following from the AccessFlow team:

| Item                         | Description                                              |
| ---------------------------- | -------------------------------------------------------- |
| **Registry Install Token**   | A base64-encoded service account key for package installation |
| **SDK API Key**              | Your project API key for runtime authentication          |

> **Important:** The **Registry Install Token** is used to download/install the SDK package. The **SDK API Key** is used at runtime when running accessibility audits. These are two separate credentials.

> **Note for npm users:** npm's `.npmrc` `_password` field is automatically base64-decoded before being sent. This means the token stored in `_password` must be **double base64-encoded** (i.e., `base64(base64(json_key))`). The AccessFlow team will provide the correct token for each package manager. See the [JavaScript/TypeScript documentation](./node/README.md) for details.

---

## Quick Start

### JavaScript/TypeScript

**1. Configure registry authentication**

Create a `.npmrc` file in your project root:

```ini
@acsbe:registry=https://NPM_REGISTRY_URL/
//NPM_REGISTRY_URL/:username=_json_key_base64
//NPM_REGISTRY_URL/:_password=NPM_INSTALL_TOKEN
//NPM_REGISTRY_URL/:always-auth=true
```

> Replace `NPM_REGISTRY_URL` and `NPM_INSTALL_TOKEN` with the values provided by the AccessFlow team. The npm token is double base64-encoded — see the [JavaScript/TypeScript documentation](./node/README.md) for details.

**2. Install the SDK**

```bash
npm install -D @acsbe/accessflow-sdk
```

**3. Use in your tests**

```typescript
import { test } from '@playwright/test';
import AccessFlowSDK from '@acsbe/accessflow-sdk';

// Set ACCESSFLOW_SDK_API_KEY in your environment
// SDK automatically uses it - no initialization needed

test('accessibility check', async ({ page }) => {
  const sdk = new AccessFlowSDK(page);
  await page.goto('https://example.com');

  const audits = await sdk.audit();
  const report = await sdk.generateReport(audits);

  console.log('Issues found:', report.numberOfIssuesFound);
});
```

[**Full JavaScript/TypeScript Documentation →**](./node/README.md)

---

### Python

**1. Install the SDK**

```bash
pip install accessflow-sdk \
  --index-url https://_json_key_base64:REGISTRY_INSTALL_TOKEN@PYTHON_REGISTRY_URL/simple/
```

> Replace `PYTHON_REGISTRY_URL` and `REGISTRY_INSTALL_TOKEN` with the values provided by the AccessFlow team.

**2. Use in your tests**

```python
from playwright.sync_api import Page
from accessflow_sdk import AccessFlowSDK

# Set ACCESSFLOW_SDK_API_KEY in your environment
# SDK automatically uses it - no api_key parameter needed

def test_accessibility(page: Page):
    sdk = AccessFlowSDK(page)
    page.goto('https://example.com')

    audits = sdk.audit()
    report = sdk.generate_report(audits)

    print(f"Issues found: {report['numberOfIssuesFound']}")
```

[**Full Python Documentation →**](./python/README.md)

---

### Java

**1. Add the Maven repository to your `pom.xml`**

```xml
<repositories>
  <repository>
    <id>accessflow-registry</id>
    <url>https://MAVEN_REGISTRY_URL</url>
  </repository>
</repositories>

<dependency>
    <groupId>com.acsbe</groupId>
    <artifactId>accessflow-sdk</artifactId>
    <version>1.0.1</version>
    <scope>test</scope>
</dependency>
```

**2. Configure authentication in `~/.m2/settings.xml`**

```xml
<settings>
  <servers>
    <server>
      <id>accessflow-registry</id>
      <username>_json_key_base64</username>
      <password>REGISTRY_INSTALL_TOKEN</password>
    </server>
  </servers>
</settings>
```

> Replace `MAVEN_REGISTRY_URL` and `REGISTRY_INSTALL_TOKEN` with the values provided by the AccessFlow team.

**3. Use in your tests**

```java
import com.acsbe.accessflow.AccessFlowSDK;
import com.microsoft.playwright.*;

// Set ACCESSFLOW_SDK_API_KEY in your environment
// SDK automatically uses it - no apiKey parameter needed

@Test
public void testAccessibility() {
    Page page = browser.newPage();
    AccessFlowSDK sdk = new AccessFlowSDK(page);

    page.navigate("https://example.com");

    Map<String, Object> audits = sdk.audit();
    Map<String, Object> report = sdk.generateReport(audits);

    System.out.println("Issues found: " + report.get("numberOfIssuesFound"));
}
```

[**Full Java Documentation →**](./java/README.md)

---

## How It Works

1. **Run your tests** - SDK audits pages as you test
2. **Collect results** - Audit data is recorded for each page
3. **Upload reports** - In CI/CD, reports automatically upload to AccessFlow Dashboard
4. **Review issues** - View detailed accessibility reports in your dashboard

## CI/CD Requirements

### Ubuntu Version Compatibility

**Important:** If using GitHub Actions or other CI/CD with Ubuntu runners, use **Ubuntu 22.04** instead of `ubuntu-latest`:

```yaml
runs-on: ubuntu-22.04  # ✅ Recommended
# runs-on: ubuntu-latest  # ❌ Currently maps to Ubuntu 24.04 which has Playwright compatibility issues
```

Ubuntu 24.04 has a breaking change (`libasound2` → `libasound2t64`) that causes Playwright browser installation to fail. This will be resolved in future Playwright releases, but for now, stick with Ubuntu 22.04 for stability.

## SDK API Key Configuration

The SDK API Key authenticates your audit requests at runtime. This is separate from the Registry Install Token used during package installation.

### Option 1: Environment Variable (Recommended)

Set `ACCESSFLOW_SDK_API_KEY` in your environment. The SDK reads it automatically — no code changes needed.

**Local development:**

```bash
# .env file (use with dotenv)
ACCESSFLOW_SDK_API_KEY=your-api-key-here

# Or export in your shell
export ACCESSFLOW_SDK_API_KEY=your-api-key-here
```

**CI/CD (store as a secret):**

| Platform         | Where to set it                                          |
| ---------------- | -------------------------------------------------------- |
| GitHub Actions   | Repository Settings → Secrets → `ACCESSFLOW_SDK_API_KEY` |
| CircleCI         | Project Settings → Environment Variables                 |
| GitLab CI        | Project Settings → CI/CD → Variables                     |
| Jenkins          | Credentials → Secret Text                                |
| Azure Pipelines  | Pipeline Variables (secret)                              |
| Bitbucket        | Repository Settings → Pipeline Variables                 |

### Option 2: Programmatic Initialization

When you need to set the API key in code:

```typescript
// JavaScript/TypeScript - Initialize once before tests
import AccessFlowSDK from '@acsbe/accessflow-sdk';
AccessFlowSDK.init({ apiKey: process.env.ACCESSFLOW_SDK_API_KEY! });
```

```python
# Python - Pass to constructor
sdk = AccessFlowSDK(page, api_key='your-api-key')
```

```java
// Java - Pass to constructor
AccessFlowSDK sdk = new AccessFlowSDK(page, "your-api-key");
```

## Configuration

Configure thresholds to fail builds on accessibility issues. Create `accessflow.config.json` in your project root:

```json
{
  "issuesFoundThreshold": {
    "extreme": 0,
    "high": 5,
    "medium": 10,
    "low": 20
  }
}
```

## Documentation

### Language-Specific Guides

- [JavaScript/TypeScript Documentation](./node/README.md)
- [Python Documentation](./python/README.md)
- [Java Documentation](./java/README.md)

## License

[ISC License](./LICENSE)
