# AccessFlow SDK for Python

Professional accessibility testing for Python applications using Playwright. Automatically detect WCAG 2.1 accessibility issues in your tests.

## Prerequisites

You will receive the following from the AccessFlow team:

| Item                       | Description                                                  |
| -------------------------- | ------------------------------------------------------------ |
| **Registry Install Token** | A base64-encoded service account key for package installation |
| **Python Registry URL**    | The private Python registry URL for the SDK package          |
| **SDK API Key**            | Your project API key for runtime authentication              |

> **Important:** The **Registry Install Token** is used to download/install the SDK package. The **SDK API Key** is used at runtime when running accessibility audits. These are two separate credentials.

## Installation

### Option 1: Install from Package Registry

```bash
pip install accessflow-sdk \
  --index-url https://_json_key_base64:REGISTRY_INSTALL_TOKEN@PYTHON_REGISTRY_URL/simple/
```

> Replace `PYTHON_REGISTRY_URL` and `REGISTRY_INSTALL_TOKEN` with the values provided by the AccessFlow team.

#### Using a pip config file (recommended for repeated installs)

Create or update `pip.conf` (Linux/macOS: `~/.config/pip/pip.conf`, Windows: `%APPDATA%\pip\pip.ini`):

```ini
[global]
extra-index-url = https://_json_key_base64:REGISTRY_INSTALL_TOKEN@PYTHON_REGISTRY_URL/simple/
```

Then install normally:

```bash
pip install accessflow-sdk
```

#### Using a requirements file

Add to your `requirements.txt`:

```txt
--extra-index-url https://_json_key_base64:REGISTRY_INSTALL_TOKEN@PYTHON_REGISTRY_URL/simple/
accessflow-sdk
```

#### Using the Registry Install Token in CI/CD

Store the token as a CI/CD secret (e.g., `ACCESSFLOW_REGISTRY_TOKEN`) and reference it:

```bash
pip install accessflow-sdk \
  --index-url https://_json_key_base64:${ACCESSFLOW_REGISTRY_TOKEN}@PYTHON_REGISTRY_URL/simple/
```

### Option 2: Install from Local Package File

If you've received a package file directly:

```bash
# Install from wheel file (recommended)
pip install /path/to/accessflow_sdk-1.0.1-py3-none-any.whl

# Or from tar.gz source distribution
pip install /path/to/accessflow_sdk-1.0.1.tar.gz
```

## Quick Start

### 1. Configure SDK API Key

**Option A: Environment Variable (Recommended)**

Set `ACCESSFLOW_SDK_API_KEY` in your environment — the SDK reads it automatically:

```bash
# .env file or shell
export ACCESSFLOW_SDK_API_KEY=your-api-key-here
```

```python
from accessflow_sdk import AccessFlowSDK

# No api_key parameter needed - reads from environment automatically
sdk = AccessFlowSDK(page)
```

**Option B: Pass to Constructor**

When you need to set the API key programmatically:

```python
sdk = AccessFlowSDK(page, api_key='your-api-key-here')
```

**Option C: Use Configuration Dictionary**

For advanced configuration:

```python
sdk = AccessFlowSDK(page, config={
    'apiToken': 'your-api-key-here',
    'projectId': 'your-project-id',
    'includeNotices': True
})
```

### 2. Basic Usage

```python
from playwright.sync_api import sync_playwright
from accessflow_sdk import AccessFlowSDK

def test_homepage_accessibility():
    with sync_playwright() as p:
        browser = p.chromium.launch()
        page = browser.new_page()

        # Initialize SDK
        sdk = AccessFlowSDK(page)
        page.goto("https://example.com")

        # Run audit
        audits = sdk.audit()
        report = sdk.generate_report(audits)

        # Check results
        print(f"Issues found: {report['numberOfIssuesFound']}")
        assert report['numberOfIssuesFound'].get('extreme', 0) == 0

        browser.close()
```

### 3. Pytest Integration (Recommended)

Create `conftest.py`:

```python
import pytest
from accessflow_sdk import AccessFlowSDK, finalize_reports

@pytest.fixture
def sdk(page):
    """Provides AccessFlow SDK instance"""
    return AccessFlowSDK(page)

def pytest_sessionfinish(session, exitstatus):
    """
    Global teardown: finalize all accessibility reports.
    This runs once after all tests have completed.
    Aggregates and uploads reports in CI environments (when ACCESSFLOW_SDK_API_KEY is set).
    """
    finalize_reports()
```

**How it works:**

1. Each call to `sdk.audit()` automatically records results for aggregation
2. After all tests complete, `pytest_sessionfinish()` runs once to:
   - Aggregate all recorded audits into a single report
   - Upload the report to AccessFlow (in CI environments with `ACCESSFLOW_SDK_API_KEY` set)
   - Validate against configured thresholds (if any)

**No manual recording needed** — just call `audit()` in your tests and configure the session finish hook.

Then use in your tests:

```python
def test_homepage(page, sdk):
    page.goto("https://example.com")

    audits = sdk.audit()
    report = sdk.generate_report(audits)

    # Assert no critical issues
    assert report['numberOfIssuesFound'].get('extreme', 0) == 0
    assert report['numberOfIssuesFound'].get('high', 0) <= 5
```

## API Reference

### AccessFlowSDK

```python
class AccessFlowSDK(page, config=None)
```

**Parameters:**

- `page` (Page): Playwright Page object
- `config` (dict, optional): Configuration dictionary
  - `apiToken` (str): API key (defaults to `ACCESSFLOW_SDK_API_KEY` env var)
  - `projectId` (str): Project ID (optional)
  - `includeNotices` (bool): Include notices in reports (default: False)

#### Methods

##### `audit() -> dict`

Runs accessibility audit on the current page and returns raw audit data.

```python
audits = sdk.audit()
```

**Returns:** Dictionary containing raw audit results

> **Note:** `audit()` automatically records results for CI/CD report aggregation. You don't need to manually call `record_audit()`. Just configure a session-level teardown to call `finalize_reports()` (see [pytest Fixture Setup](#pytest-fixture-setup)).

##### `generate_report(audits, export_type='json') -> dict`

Generates a summary report from audit results.

```python
report = sdk.generate_report(audits)
```

**Parameters:**

- `audits` (dict): Raw audit data from `audit()`
- `export_type` (str): Report format (currently only 'json')

**Returns:**

```python
{
    'numberOfIssuesFound': {
        'extreme': 0,
        'high': 5,
        'medium': 8,
        'low': 12
    },
    'ruleViolations': {
        'colorContrast': {
            'name': 'Color Contrast',
            'severity': 'medium',
            'numberOfOccurrences': 3,
            'WCAGLevel': 'AA',
            'WCAGLink': 'https://www.w3.org/WAI/WCAG21/...',
            'description': 'Ensure sufficient color contrast...',
            'selectors': ['.header', '.footer']
        }
    }
}
```

### Teardown Functions

#### `record_audit(url: str, audits: dict)`

Records an audit for later aggregation (useful for parallel test execution).

```python
from accessflow_sdk import record_audit

record_audit(page.url, audits)
```

#### `finalize_reports(api_key: str = None, run_id: str = None, output_dir: str = './test-results')`

Finalizes and uploads all recorded audits. Call this once after all tests complete.

```python
from accessflow_sdk import finalize_reports

finalize_reports()
```

**Parameters:**

- `api_key` (str, optional): Override API key from environment
- `run_id` (str, optional): Custom run ID for reports
- `output_dir` (str): Directory for local JSON reports (default: './test-results')

## Configuration

Create `accessflow.config.json` in your project root:

```json
{
  "issuesFoundThreshold": {
    "extreme": 0,
    "high": 5,
    "medium": 10,
    "low": 20
  },
  "localCheck": false
}
```

**Options:**

- `issuesFoundThreshold`: Maximum allowed issues per severity level
- `localCheck`: Apply thresholds in local development (default: false, applies in CI only)

## How It Works

### Local Development

- ✅ Audits run on each page
- ✅ JSON reports saved to `./test-results` directory
- ❌ Reports NOT uploaded to dashboard (prevents accidental uploads)

### CI/CD Environment

- ✅ Audits run on each page
- ✅ Results aggregated from parallel test workers
- ✅ Automatically uploaded to AccessFlow dashboard
- ✅ Threshold checks applied (fail build if exceeded)

**Supported CI platforms:** CircleCI, GitHub Actions, GitLab CI, Jenkins, Azure Pipelines, Bitbucket Pipelines, Travis CI

## CI/CD Integration

In CI/CD pipelines, you need secrets and variables:

**Secrets:**

| Secret                       | Purpose                        |
| ---------------------------- | ------------------------------ |
| `ACCESSFLOW_REGISTRY_TOKEN`  | Install the SDK package        |
| `ACCESSFLOW_SDK_API_KEY`     | Authenticate audit requests    |

**Variables:**

| Variable                        | Purpose                           | Example                                                    |
| ------------------------------- | --------------------------------- | ---------------------------------------------------------- |
| `GCP_SDK_PYTHON_REGISTRY_URL`   | Python registry URL (without `https://`) | `us-east1-python.pkg.dev/PROJECT/stag-accessflow-python` |

> **Important:** Do not include `https://` in the registry URL variable - it's added automatically in the pip install command.

### GitHub Actions

```yaml
name: Accessibility Tests

on: [push]

jobs:
  test:
    runs-on: ubuntu-22.04  # Use 22.04 for Playwright compatibility
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-python@v4
        with:
          python-version: '3.10'
      - run: |
          pip install -r requirements.txt
          pip install accessflow-sdk \
            --index-url https://_json_key_base64:${ACCESSFLOW_REGISTRY_TOKEN}@PYTHON_REGISTRY_URL/simple/
          playwright install chromium
        env:
          ACCESSFLOW_REGISTRY_TOKEN: ${{ secrets.ACCESSFLOW_REGISTRY_TOKEN }}
      - run: pytest -v
        env:
          ACCESSFLOW_SDK_API_KEY: ${{ secrets.ACCESSFLOW_SDK_API_KEY }}
```

### CircleCI

```yaml
jobs:
  test:
    docker:
      - image: cimg/python:3.10
    steps:
      - checkout
      - run: |
          pip install -r requirements.txt
          pip install accessflow-sdk \
            --index-url https://_json_key_base64:${ACCESSFLOW_REGISTRY_TOKEN}@PYTHON_REGISTRY_URL/simple/
          playwright install chromium
      - run: pytest -v
    environment:
      ACCESSFLOW_REGISTRY_TOKEN: ${ACCESSFLOW_REGISTRY_TOKEN}
      ACCESSFLOW_SDK_API_KEY: ${ACCESSFLOW_SDK_API_KEY}
```

### GitLab CI

```yaml
test:
  image: python:3.10
  variables:
    ACCESSFLOW_REGISTRY_TOKEN: $ACCESSFLOW_REGISTRY_TOKEN
    ACCESSFLOW_SDK_API_KEY: $ACCESSFLOW_SDK_API_KEY
  script:
    - pip install -r requirements.txt
    - pip install accessflow-sdk
        --index-url https://_json_key_base64:${ACCESSFLOW_REGISTRY_TOKEN}@PYTHON_REGISTRY_URL/simple/
    - playwright install chromium
    - pytest -v
```

## Advanced Usage

### Custom Configuration

```python
sdk = AccessFlowSDK(page, config={
    'apiToken': 'your-api-key',
    'projectId': 'your-project-id',
    'includeNotices': True
})
```

### Multiple Pages

```python
def test_multi_page(page, sdk):
    # Test homepage
    page.goto("https://example.com")
    home_audits = sdk.audit()

    # Test about page
    page.goto("https://example.com/about")
    about_audits = sdk.audit()

    # Generate reports
    home_report = sdk.generate_report(home_audits)
    about_report = sdk.generate_report(about_audits)
```

### Async Playwright

```python
import pytest
from playwright.async_api import async_playwright
from accessflow_sdk import AccessFlowSDK

@pytest.mark.asyncio
async def test_async_accessibility():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()

        sdk = AccessFlowSDK(page)
        await page.goto("https://example.com")

        audits = sdk.audit()  # Note: audit() is synchronous
        report = sdk.generate_report(audits)

        assert report['numberOfIssuesFound'].get('extreme', 0) == 0
        await browser.close()
```

## Requirements

- Python 3.7+
- Playwright for Python (`pip install playwright`)
- Playwright browsers installed (`playwright install`)

## Troubleshooting

### API Key Issues

```python
# Check if environment variable is set
import os
print(os.getenv('ACCESSFLOW_SDK_API_KEY'))

# Pass API key explicitly
sdk = AccessFlowSDK(page, api_key='your-api-key')

# Or use config dict
sdk = AccessFlowSDK(page, config={'apiToken': 'your-api-key'})
```

**Never hardcode API keys in your source code!** Use:

- Constructor parameters for local development
- Environment variables for CI/CD (stored as secrets)
- Configuration files excluded from version control

### Reports Not Uploading

- Ensure `CI=true` is set in your CI environment
- Check `finalize_reports()` is called after all tests
- Verify API key has upload permissions

### Playwright Browser Not Found

```bash
# Install Playwright browsers
playwright install chromium
```

## License

ISC
