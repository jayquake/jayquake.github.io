"""
SHA-256 checksums for CLI binaries.
DO NOT EDIT MANUALLY - This file is generated during the build process.

These checksums are computed from the CLI binaries when the SDK is packaged.
They are verified at runtime before executing any binary to ensure integrity
and protect against supply chain attacks.

To regenerate checksums, run: ./scripts/generate-checksums.sh

During development, you can set these to "DEVELOPMENT_MODE_NO_CHECKSUM" to
skip verification (not recommended for production builds).
"""

BINARY_CHECKSUMS = {
    # Checksum for macOS ARM64 (Apple Silicon) binary
    "aflow-core-macos-arm64": "DEVELOPMENT_MODE_NO_CHECKSUM",

    # Checksum for macOS x64 (Intel) binary
    "aflow-core-macos-x64": "DEVELOPMENT_MODE_NO_CHECKSUM",

    # Checksum for Linux x64 binary
    "aflow-core-linux-x64": "DEVELOPMENT_MODE_NO_CHECKSUM",

    # Checksum for Windows x64 binary
    "aflow-core-win-x64.exe": "DEVELOPMENT_MODE_NO_CHECKSUM",
}
