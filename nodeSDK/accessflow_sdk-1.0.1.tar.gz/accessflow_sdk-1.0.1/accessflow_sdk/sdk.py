"""
AccessFlow SDK main class for Python
"""
import subprocess
import platform
import tempfile
import json
import os
import base64
import hashlib
from typing import Dict, Any, Optional
from pathlib import Path
try:
    import urllib.request
    import urllib.error
except ImportError:
    # Python 2 fallback (shouldn't happen in modern code)
    import urllib2 as urllib

# Import checksums (generated during build)
try:
    from .checksums import BINARY_CHECKSUMS
except ImportError:
    # Development mode - no checksums available
    BINARY_CHECKSUMS = {}


class AccessFlowSDK:
    """AccessFlow SDK for accessibility testing with Playwright"""

    def __init__(self, page, api_key: Optional[str] = None, config: Optional[Dict[str, Any]] = None):
        """
        Initialize AccessFlow SDK

        Args:
            page: Playwright Page object
            api_key: AccessFlow API key (defaults to ACCESSFLOW_SDK_API_KEY env var)
            config: Optional configuration dictionary (apiToken, projectId, includeNotices, etc.)
        """
        self.page = page

        # Handle config dict for compatibility with examples
        if config:
            self.api_key = config.get('apiToken') or api_key or os.environ.get('ACCESSFLOW_SDK_API_KEY')
            self.project_id = config.get('projectId')
            self.include_notices = config.get('includeNotices', True)
        else:
            self.api_key = api_key or os.environ.get('ACCESSFLOW_SDK_API_KEY')
            self.project_id = None
            self.include_notices = True

        self._cli_path = self._get_cli_path()
        self._auditor_js = self._load_auditor()
        self._auditor_css = self._load_auditor_css()
        self._api_key_verified = False  # Cache verification status

    def _get_cli_path(self) -> str:
        """Determine the correct CLI binary path for current platform.

        Verifies the binary checksum before returning to ensure integrity.
        """
        system = platform.system().lower()
        machine = platform.machine().lower()

        # Get package directory
        package_dir = Path(__file__).parent
        bin_dir = package_dir / "bin"

        if system == 'darwin':
            arch = 'arm64' if 'arm' in machine or 'aarch64' in machine else 'x64'
            binary = f"aflow-core-macos-{arch}"
        elif system == 'linux':
            binary = "aflow-core-linux-x64"
        elif system == 'windows':
            binary = "aflow-core-win-x64.exe"
        else:
            raise RuntimeError(f"Unsupported platform: {system}")

        path = bin_dir / binary

        if not path.exists():
            raise FileNotFoundError(
                f"CLI binary not found at {path}. "
                "Package may be corrupted."
            )

        # Verify checksum before execution (security measure)
        self._verify_binary_checksum(path, binary)

        # Make executable on Unix systems
        if system != 'windows':
            os.chmod(path, 0o755)

        return str(path)

    def _verify_binary_checksum(self, binary_path: Path, binary_name: str) -> None:
        """Verify the SHA-256 checksum of the CLI binary.

        Args:
            binary_path: Path to the binary file
            binary_name: Name of the binary (used to lookup expected checksum)

        Raises:
            SecurityError: If checksum verification fails
        """
        expected_checksum = BINARY_CHECKSUMS.get(binary_name)

        # Skip verification if no checksum is configured (development mode)
        if not expected_checksum or expected_checksum == "DEVELOPMENT_MODE_NO_CHECKSUM":
            return

        actual_checksum = self._compute_sha256(binary_path)

        if expected_checksum.lower() != actual_checksum.lower():
            raise SecurityError(
                f"AccessFlowSDK: Binary integrity check failed for {binary_name}. "
                f"Expected checksum: {expected_checksum}, "
                f"Actual checksum: {actual_checksum}. "
                "This may indicate a corrupted or tampered package. "
                "Please reinstall the SDK from a trusted source."
            )

    @staticmethod
    def _compute_sha256(file_path: Path) -> str:
        """Compute the SHA-256 hash of a file.

        Args:
            file_path: Path to the file

        Returns:
            Lowercase hexadecimal SHA-256 hash
        """
        sha256_hash = hashlib.sha256()

        with open(file_path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                sha256_hash.update(chunk)

        return sha256_hash.hexdigest()

    def _load_auditor(self) -> str:
        """Load the auditor.js script"""
        package_dir = Path(__file__).parent
        auditor_path = package_dir / "assets" / "auditor.js"

        if not auditor_path.exists():
            raise FileNotFoundError(f"auditor.js not found at {auditor_path}")

        return auditor_path.read_text()

    def _load_auditor_css(self) -> str:
        """Load the auditor.css stylesheet"""
        package_dir = Path(__file__).parent
        css_path = package_dir / "assets" / "auditor.css"

        if not css_path.exists():
            return ""

        return css_path.read_text()

    @staticmethod
    def _enforce_https(url_string: str) -> None:
        """
        Enforce that a URL uses HTTPS protocol.
        This is a security measure to prevent API key transmission over insecure connections.

        Args:
            url_string: The URL to validate

        Raises:
            SecurityError: If the URL does not use HTTPS
        """
        from urllib.parse import urlparse
        parsed = urlparse(url_string)
        if parsed.scheme.lower() != 'https':
            raise SecurityError(
                f"AccessFlowSDK: Security error - API calls must use HTTPS. "
                f"Received URL with protocol: {parsed.scheme}. "
                "This prevents API key transmission over insecure connections."
            )

    def _verify_api_key(self) -> None:
        """
        Verify the API key with the AccessFlow server.
        Raises an exception if the key is invalid.
        Only verifies once per SDK instance (cached).
        """
        # Return early if already verified
        if self._api_key_verified:
            return

        if not self.api_key:
            raise ValueError(
                "AccessFlowSDK: API key is missing. Please set ACCESSFLOW_SDK_API_KEY "
                "in your environment or pass api_key to the constructor."
            )

        # Get base URL and auth from generated config (injected during build from sdk.config.ts)
        try:
            from . import sdk_config
            base_url = sdk_config.BASE_URL
            auth_string = sdk_config.DEV_AUTH
            auth_header = 'Basic ' + base64.b64encode(auth_string.encode()).decode() if auth_string else None
        except ImportError:
            # Fallback if config not generated (development mode)
            base_url = os.environ.get('ACCESSFLOW_BASE_URL', 'https://accessflow.accessibe.com')
            auth_header = None

        # Skip verification if base URL is not available
        if not base_url:
            return

        verify_url = f"{base_url}/api/v6/sdk/verify-sdk-api-key"

        # Enforce HTTPS to protect API key in transit
        self._enforce_https(verify_url)

        try:
            # Create request without data (no body, just like Node.js fetch)
            request = urllib.request.Request(verify_url)
            request.get_method = lambda: 'POST'

            # Add User-Agent to avoid Cloudflare bot detection (error 1010)
            request.add_header('User-Agent', 'Mozilla/5.0 (compatible; AccessFlowSDK/1.0)')

            # Add headers exactly as Node.js does
            # Note: urllib normalizes header names, but servers should be case-insensitive
            request.add_header('x-api-key', self.api_key)
            if auth_header:
                request.add_header('Authorization', auth_header)

            with urllib.request.urlopen(request, timeout=10) as response:
                # We only care that the request succeeded (status 200)
                # No need to read the response body
                pass
            self._api_key_verified = True  # Cache successful verification
        except urllib.error.HTTPError as e:
            error_text = e.read().decode('utf-8', errors='ignore')
            raise ValueError(f"AccessFlowSDK: invalid API key. HTTP {e.code}: {error_text[:100]}")
        except Exception as e:
            raise ValueError(f"AccessFlowSDK: API key verification failed. {str(e)}")

    def audit(self) -> Dict[str, Any]:
        """
        Run accessibility audit on the current page

        Returns:
            Dictionary containing RAW audit data from the browser.
            Use generate_report() to process into a formatted report.
        """
        # Verify API key before running audit
        self._verify_api_key()

        # Inject auditor.js by creating a script tag (matches TypeScript SDK approach)
        self.page.evaluate(
            """(scriptContent) => {
                if (!window.accessFlow) {
                    const script = document.createElement('script');
                    script.textContent = scriptContent;
                    document.documentElement.appendChild(script);
                }
            }""",
            self._auditor_js
        )

        # Inject CSS
        if self._auditor_css:
            self.page.evaluate(
                """(cssContent) => {
                    if (!document.getElementById('accessflow-auditor-style')) {
                        const style = document.createElement('style');
                        style.id = 'accessflow-auditor-style';
                        style.textContent = cssContent;
                        document.head.appendChild(style);
                    }
                }""",
                self._auditor_css
            )

        # Run the audit and get raw results
        raw_audits = self.page.evaluate("() => window.accessFlow?.getLoadAudits()")

        if raw_audits is None:
            return {}

        # Auto-record audit results for report aggregation (CI/CD reporting)
        if raw_audits:
            from .teardown import record_audit
            record_audit(self.page.url, raw_audits)

        # Return raw audits (matches TypeScript SDK behavior)
        return raw_audits if raw_audits else {}

    def generate_report(
        self,
        audits: Dict[str, Any],
        export_type: str = 'json'
    ) -> Dict[str, Any]:
        """
        Generate accessibility report from audit results

        Args:
            audits: Raw audit results from audit()
            export_type: Report format ('json' only)

        Returns:
            Dictionary with summarized report including issue counts and violations
        """
        # Write audits to temporary file (handles large data)
        temp_file = None
        try:
            with tempfile.NamedTemporaryFile(
                mode='w',
                suffix='.json',
                delete=False
            ) as f:
                json.dump(audits, f)
                temp_file = f.name

            # Call CLI to process audits
            result = subprocess.run(
                [
                    self._cli_path,
                    'process',
                    '--file', temp_file,
                    '--url', self.page.url
                ],
                capture_output=True,
                text=True,
                check=True
            )

            report = json.loads(result.stdout)
            return report

        except subprocess.CalledProcessError as e:
            error_msg = e.stderr if e.stderr else str(e)
            raise RuntimeError(f"Failed to generate report: {error_msg}")
        finally:
            # Clean up temp file - suppress any errors to ensure cleanup doesn't fail
            if temp_file:
                try:
                    os.unlink(temp_file)
                except OSError:
                    pass  # Best effort cleanup


class SecurityError(Exception):
    """Raised when a security check fails."""
    pass
