"""
Auto-generated configuration from sdk.config.ts
DO NOT EDIT MANUALLY - This file is generated during build
"""

BASE_URL = "https://sdk-refactor--accessflow--test.acsb-test.com/"
DEV_AUTH = "test:acsb123"
IS_PRODUCTION = False
